const $=s=>document.querySelector(s);
const norm=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9ñ ]/g,'').replace(/\s+/g,' ').trim();
// --- 3D ---
const bin=Uint8Array.from(atob(D.b),c=>c.charCodeAt(0)).buffer;
const cv=$('#cv'),R=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});R.setPixelRatio(Math.min(devicePixelRatio,2));
const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(30,1,.05,5);
sc.add(new THREE.HemisphereLight(0xffffff,0x222233,.9));const dl=new THREE.DirectionalLight(0xffffff,.8);dl.position.set(.5,1,1);cam.add(dl);sc.add(cam);
const root=new THREE.Group();sc.add(root);
const mats={ghost:new THREE.MeshPhongMaterial({color:0xcfd2d8,transparent:true,opacity:.22,depthWrite:false,shininess:30}),
 hot:new THREE.MeshPhongMaterial({color:0xe0283b,emissive:0x5a0810,shininess:40}),warm:new THREE.MeshPhongMaterial({color:0xc4545e,transparent:true,opacity:.5,depthWrite:false,shininess:30})};
const mk3=new THREE.Mesh(new THREE.SphereGeometry(.0045,20,16),new THREE.MeshBasicMaterial({color:0xff2d44,depthTest:false,transparent:true}));mk3.renderOrder=9;mk3.visible=false;root.add(mk3);const ring=new THREE.Mesh(new THREE.SphereGeometry(.0075,20,16),new THREE.MeshBasicMaterial({color:0xff2d44,depthTest:false,transparent:true,opacity:.25}));ring.renderOrder=8;mk3.add(ring);
const meshes={};
D.parts.forEach(p=>{const g=new THREE.BufferGeometry(),q=new Int16Array(bin,p.p,p.v*3),n=new Int16Array(bin,p.n,p.v*3);
 g.setAttribute('position',new THREE.BufferAttribute(Float32Array.from(q,x=>x*D.S),3));
 g.setAttribute('normal',new THREE.BufferAttribute(Float32Array.from(n,x=>x/32767),3));
 g.setIndex(new THREE.BufferAttribute(new Uint16Array(bin,p.i,p.c),1));g.computeBoundingBox();
 const m=new THREE.Mesh(g,mats.ghost);root.add(m);meshes[p.id]=m;});
function center(ids){const b=new THREE.Box3();ids.forEach(i=>b.union(meshes[i].geometry.boundingBox));return b.getCenter(new THREE.Vector3())}
function resize(){const w=cv.clientWidth,h=cv.clientHeight;R.setSize(w,h,false);cam.aspect=w/h;cam.position.set(0,0,w/h<.8?1.15:.8);cam.updateProjectionMatrix()}
addEventListener('resize',resize);
let tgtY=0,tgtX=0,drag=null,zoom=1,zt=1,zsm=1,tgtPY=0;
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};cv.setPointerCapture(e.pointerId)});
cv.addEventListener('pointermove',e=>{if(!drag)return;root.rotation.y+=(e.clientX-drag.x)*.01;root.rotation.x=Math.max(-.8,Math.min(.8,root.rotation.x+(e.clientY-drag.y)*.006));tgtY=root.rotation.y;drag={x:e.clientX,y:e.clientY};});
let pd=0;cv.addEventListener('touchmove',e=>{if(e.touches.length==2){const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(pd)zoom=Math.max(.5,Math.min(2.5,zoom*d/pd));pd=d;drag=null}},{passive:true});cv.addEventListener('touchend',()=>pd=0);cv.addEventListener('pointerup',()=>drag=null);
cv.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.5,Math.min(2,zoom*(1+e.deltaY*.001)))},{passive:false});
let free=false;
(function loop(){requestAnimationFrame(loop);if(!drag&&!free){let d=tgtY-root.rotation.y;root.rotation.y+=d*.07;root.rotation.x+=(tgtX-root.rotation.x)*.07}ring.scale.setScalar(1+.25*Math.sin(Date.now()/250));
 zsm+=(zt-zsm)*.08;root.position.y+=(tgtPY-root.position.y)*.08;cam.zoom=zsm*zoom;cam.updateProjectionMatrix();R.render(sc,cam)})();
const BONE=new Set(D.bi),CC={mus:0xb8503c,art:0xd8283a,ven:0x3b72e0,ner:0xe8c64a},cm={},tm={};
for(const k in CC){cm[k]=new THREE.MeshPhongMaterial({color:CC[k],transparent:true,opacity:.2,depthWrite:false});tm[k]=new THREE.MeshPhongMaterial({color:CC[k],emissive:CC[k],emissiveIntensity:.3,shininess:40})}
function show(g,flip){for(const i in meshes){meshes[i].visible=BONE.has(i);meshes[i].material=mats.ghost}mk3.visible=false;tgtX=0;tgtPY=0;zt=1;
 if(!g)return;let c;
 if(g.pts){g.ids.forEach(i=>meshes[i].material=mats.warm);const p=g.pts[g.pts.length>1&&flip?1:0];c=new THREE.Vector3(...p);mk3.position.copy(c);mk3.visible=true;if(g.u)tgtX=-.85;if(g.pts.length<2&&flip){tgtY=nearest(Math.atan2(c.x,c.z)+1.1);return}flip=false}
 else if(g.cat){D[g.cat].forEach(x=>x.ids.forEach(i=>{meshes[i].visible=true;meshes[i].material=cm[g.cat]}));g.ids.forEach(i=>meshes[i].material=tm[g.cat]);
  const bb=new THREE.Box3();g.ids.forEach(i=>bb.union(meshes[i].geometry.boundingBox));c=bb.getCenter(new THREE.Vector3());const s=bb.getSize(new THREE.Vector3()).length();zt=s<.04?2.8:s<.08?1.9:s<.14?1.35:1;tgtPY=-c.y}
 else{g.ids.forEach(i=>meshes[i].material=mats.hot);c=center(g.ids)}
 const az=Math.atan2(c.x,c.z)+(flip?Math.PI:0);tgtY=nearest(az)}
function nearest(t){const cur=root.rotation.y,tw=2*Math.PI;return t+Math.round((cur-t)/tw)*tw}
// --- teclado ---
const rows=['qwertyuiop','asdfghjklñ','zxcvbnm'];let typed='',onEnter=()=>{};
rows.forEach((r,ri)=>{const d=document.createElement('div');d.className='r';
 [...r].forEach(ch=>d.append(mk(ch,'',()=>key(ch))));
 if(ri==2)d.append(mk('⌫','w',()=>key('Backspace')));$('#kb').append(d)});
{const d=document.createElement('div');d.className='r';d.append(mk('espacio','sp',()=>key(' ')),mk('Enter','w ok',()=>key('Enter')));$('#kb').append(d)}
function mk(t,c,f){const b=document.createElement('button');b.className='k '+c;b.textContent=t;b.onclick=f;return b}
function key(k){if(!on)return;if(k=='Enter')return onEnter();if(k=='Backspace')typed=typed.slice(0,-1);else if(typed.length<28)typed+=k;draw()}
addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey)return;if(e.key=='Enter'||e.key=='Backspace'||e.key.length==1){e.preventDefault();key(e.key.length==1?e.key.toLowerCase():e.key)}});
// --- juego ---
const RN=['con ayuda','de memoria','de memoria, otro lado'];
let on=false,Q=[],r=0,qi=0,tries=0,res=[],cur;
function draw(){$('#word').textContent=typed+'|'}
function start(list){Q=[...list].sort(()=>Math.random()-.5);r=0;qi=0;res=Q.map(()=>[null,null,null]);$('#ov').style.display='none';on=true;ask()}
function ask(){cur=Q[qi];typed='';tries=0;draw();$('#word').className='';
 $('#st').textContent=`Ronda ${r+1} · ${RN[r]} · ${qi+1} / ${Q.length}`;
 const full=cur.k.replace(/[^ ]/g,'_').split('').join(' ');$('#hint').textContent=r==0?`${cur.h?cur.h+' · ':''}${full}`:(cur.h&&r==1?'':'');
 show(cur,r==2);onEnter=check}
function check(){const t=norm(typed);if(!t)return;
 if(cur.a.includes(t)){res[qi][r]=tries==0;fin(true)}
 else{tries++;$('#word').classList.add('shake');setTimeout(()=>$('#word').classList.remove('shake'),300);
  if(tries>=2){res[qi][r]=false;fin(false)}else{$('#hint').textContent='Casi… inténtalo otra vez. Empieza con «'+cur.k[0].toUpperCase()+'»';typed='';draw()}}}
function fin(ok){on=false;$('#word').textContent=cur.k;$('#word').className=ok?'good':'';$('#hint').textContent=ok?'¡Correcto!':'Era: '+cur.k;
 setTimeout(()=>{on=true;qi++;if(qi>=Q.length){qi=0;r++}if(r>2)return end();ask()},ok?700:1600)}
function end(){on=false;show(null);const miss=Q.filter((q,i)=>res[i].includes(false));
 const sc=[0,1,2].map(k=>res.filter(x=>x[k]).length);
 ov(`<h1>Sesión terminada</h1><p>Aciertos a la primera por ronda: ${sc.map((s,i)=>`R${i+1} ${s}/${Q.length}`).join(' · ')}</p>${miss.length?`<p>Para repasar: ${miss.map(m=>m.k).join(', ')}</p>`:'<p>¡Sin fallos!</p>'}`,
  (miss.length?[['Repasar fallos',()=>start(miss),'']]:[]).concat([['Nueva sesión',menu,'g']]))}
function ov(h,bs){const o=$('#ov');o.innerHTML=h;bs.forEach(([t,f,c])=>{const b=document.createElement('button');b.className='b '+c;b.textContent=t;b.onclick=f;o.append(b)});o.style.display='flex'}
let cat='hue';const CATS=[['hue','Huesos'],['lm','Accidentes óseos'],['mus','Músculos'],['art','Arterias'],['ven','Venas'],['ner','Nervios']];
function list(){return cat=='hue'?D.groups:D[cat]}
function menu(){free=true;on=false;root.rotation.set(.2,0,0);tgtY=0;show(null);const L=list();
 ov(`<h1>Cabeza y cuello 3D</h1><p>Una estructura se resalta. Escríbela con el teclado. Tres rondas: con ayuda, de memoria y de memoria desde otro ángulo. Arrastra para girar.</p><p style="font-size:11px;color:#8a8a93">Modelos 3D: BodyParts3D © DBCLS, licencia CC BY 4.0. Herramienta educativa.</p>`,
 CATS.map(([k,n])=>[n,()=>{cat=k;menu()},k==cat?'':'g']).concat([['Sesión de '+Math.min(8,L.length),()=>{free=false;start(L.slice().sort(()=>Math.random()-.5).slice(0,8))},''],['Todas ('+L.length+')',()=>{free=false;start(L)},'g']]))}
D.groups.concat(D.lm,D.mus,D.art,D.ven,D.ner).forEach(g=>g.a=g.a.map(norm).concat(norm(g.k)));
resize();menu();
